document.addEventListener('DOMContentLoaded', function() {
    var element = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(element, options);
});